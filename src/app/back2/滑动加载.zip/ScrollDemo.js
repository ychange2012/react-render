/**
 * In this file, we create a React component
 * which incorporates components providedby material-ui.
 */
import React, {Component} from 'react';


class Main extends Component {
  
	constructor(props, context) {
    super(props, context);
    this.state = {
      currentComponent: null
    };
  }

  componentDidMount(){
    window.addEventListener('scroll',this.handleScroll.bind(this));
  }

  handleScroll(e){
    var elem = $(e.currentTarget);
    var top = elem.scrollTop();
    var wHeight = $(document).height();
    var height = elem.height();
    console.log('top '+top);
    console.log('height '+height);
    console.log('outerHeight '+outerHeight);
    if(wHeight==top+height){
      alert('加载');
    }
  }
  
  render() {
    
   

    return (
    <div>
      <h2>test</h2>
      <div style={{backgroundColor:'#ffd9ec',height:'2000px'}}>
        <h3>00000000</h3>
      </div>
    </div>
    );
  }
}

export default Main;